package MIString.MINotation;

public interface INotation
{
	public String MyStr(String str);
}
