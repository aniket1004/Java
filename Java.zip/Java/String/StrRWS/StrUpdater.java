package MIString.MIUpdater;

public abstract class StrUpdater
{
	abstract public String RWS(String Str);
}